-- Our main game list filter registration method
function RegisterUserFilters()

	-- Create our global table
	local userFilters = {}

	-- Add a user defined filter methods
	
	-- All done
	return userFilters

end