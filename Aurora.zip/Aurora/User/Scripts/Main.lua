-- Require additional lua scripts
require("Enums")

-- Set some global settings that we can access later
ScriptVersion = 1.0

-- Let us know we are all done (Not needed..)
print(_VERSION)
print("Main.lua done!")